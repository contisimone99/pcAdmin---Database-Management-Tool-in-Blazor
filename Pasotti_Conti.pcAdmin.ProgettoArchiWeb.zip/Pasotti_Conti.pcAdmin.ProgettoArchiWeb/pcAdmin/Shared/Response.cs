﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pcAdmin.Shared
{
    public class Response
    {
        public string QueryResponse { get; set; } = string.Empty;
        public string ExportResponse { get; set; } = string.Empty;

    }
}

