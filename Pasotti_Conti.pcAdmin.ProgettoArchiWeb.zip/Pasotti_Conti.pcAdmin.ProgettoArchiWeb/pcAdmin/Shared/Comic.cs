﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pcAdmin.Shared
{
    public class Comic
    {
        public int Id { get; set; } = 1;
        public string Name { get; set; }
    }
}
